/*  meanoptions.h

    Mark Woolrich - FMRIB Image Analysis Group

    Copyright (C) 2002 University of Oxford  */

/*  CCOPYRIGHT  */

#if !defined(Diff_pvm_dwssfp_Options_h)
#define Diff_pvm_dwssfp_Options_h

#include <string>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include "utils/options.h"
#include "utils/log.h"
#include "bint/bintoptions.h"

using namespace Utilities;

namespace Bint {

class Diff_pvm_dwssfp_Options : public BintOptions {
 public:
  static Diff_pvm_dwssfp_Options& getInstance();
  ~Diff_pvm_dwssfp_Options() { delete gopt; }
  
  Option<string> bvecsfile;  
  Option<string> diffGradDurfile;
  Option<string> diffGradAmpfile;
  Option<string> flipAnglefile;
  Option<string> TRfile;
  Option<string> T1mapfile;
  Option<string> T2mapfile;
  Option<string> B1mapfile;
  
 private:
  Diff_pvm_dwssfp_Options();  
  const Diff_pvm_dwssfp_Options& operator=(Diff_pvm_dwssfp_Options&);
  Diff_pvm_dwssfp_Options(Diff_pvm_dwssfp_Options&);
      
  static Diff_pvm_dwssfp_Options* gopt;
  
};

 inline Diff_pvm_dwssfp_Options& Diff_pvm_dwssfp_Options::getInstance(){
   if(gopt == NULL)
     gopt = new Diff_pvm_dwssfp_Options();
   
   return *gopt;
 }

 inline Diff_pvm_dwssfp_Options::Diff_pvm_dwssfp_Options() :
   BintOptions("diff_pvm_dwssfp", "diff_pvm_dwssfp --verbose\n"),   
   bvecsfile(string("-r,--bvecs"),"bvecs", 
	     string("gradient directions"), 
	     true, requires_argument),
   diffGradDurfile(string("-d,--diffGradDur"),"diffGradDurs", 
	     string("Duration of Diffusion Gradient"), 
		   true, requires_argument),
   diffGradAmpfile(string("-G,--diffGradAmp"),"diffGradAmps", 
	     string("Amplitude of Diffusion Gradient"), 
		   true, requires_argument),
   flipAnglefile(string("-a,--flipAngle"),"flipAngles", 
	     string("Flip Angle"), 
		 true, requires_argument),
   TRfile(string("-T,--Repetition Time"),"TRs", 
	     string("Repetition Time"), 
	  true, requires_argument),
   T1mapfile(string("--T1,--T1mapfile"), string("T1map"),
	     string("T1map file"),
             true,requires_argument),
   T2mapfile(string("--T2,--T2mapfile"),string("T2map"),
	     string("T2map file"),
	     true, requires_argument),
   B1mapfile(string("--B1,--B1mapfile"), string("B1map"),
	     string("B1map file"),
             true, requires_argument)
   

   {
     try {
       options.add(bvecsfile);
       options.add(diffGradDurfile);
       options.add(diffGradAmpfile);
       options.add(flipAnglefile);
       options.add(TRfile);
       options.add(T1mapfile);
       options.add(T2mapfile);
       options.add(B1mapfile);
     }
     catch(X_OptionError& e) {
       options.usage();
       cerr << endl << e.what() << endl;
     } 
     catch(std::exception &e) {
       cerr << e.what() << endl;
     }    
     
   }
}

#endif





