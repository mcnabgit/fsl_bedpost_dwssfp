/* Diffusion Partial Volume Model  for DW-SSFP

Jennifer McNab - FMRIB Physics Group

    Copyright (C) 2007 University of Oxford  

*/


/*  CCOPYRIGHT  */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>
#define WANT_STREAM
#define WANT_MATH
//  #include "newmatap.h"
//  #include "newmatio.h"
#include <string>
#include <math.h>
#include "utils/log.h"
#include "diff_pvm_dwssfp_options.h"
#include "utils/tracer_plus.h"
#include "miscmaths/miscprob.h"
#include "stdlib.h"
#include "bint/model.h"
#include "bint/lsmcmcmanager.h"
//#include "bint/lslaplacemanager.h"

using namespace Bint;
using namespace Utilities;
using namespace NEWMAT;
using namespace MISCMATHS;


const float maxfloat=1e10;
const float minfloat=1e-10;
const float maxlogfloat=23;
const float minlogfloat=-23;


inline float min(float a,float b){
  return a<b ? a:b;}
inline float max(float a,float b){
  return a>b ? a:b;}
inline Matrix Anis()
{ 
  Matrix A(3,3);
  A << 1 << 0 << 0
    << 0 << 0 << 0
    << 0 << 0 << 0;

  return A;
}

inline Matrix Is()
{ 
  Matrix I(3,3);
  I << 1 << 0 << 0
    << 0 << 1 << 0
    << 0 << 0 << 1; 

  return I;
}

inline ColumnVector Cross(const ColumnVector& A,const ColumnVector& B)
{
     ColumnVector res(3);
  res << A(2)*B(3)-A(3)*B(2)
      << A(3)*B(1)-A(1)*B(3)
      << A(1)*B(2)-B(1)*A(2);

  return res;
}

inline Matrix Cross(const Matrix& A,const Matrix& B)
{
     Matrix res(3,1);
  res << A(2,1)*B(3,1)-A(3,1)*B(2,1)
      << A(3,1)*B(1,1)-A(1,1)*B(3,1)
      << A(1,1)*B(2,1)-B(1,1)*A(2,1); 

  return res;
}

float mod(float a, float b){
  while(a>b){a=a-b;}
  while(a<0){a=a+b;} 
  return a;
}


Matrix form_Amat(const Matrix& r)
{


  Matrix A(r.Ncols(),7);
  Matrix tmpvec(3,1), tmpmat;
   for( int i = 1; i <= r.Ncols(); i++){
    tmpvec << r(1,i) << r(2,i) << r(3,i); //[Ux Uy Uz]
    //JM: A "dummy" b-value of 3000 is used here. The standard DT calculation is only used to initialize the principal diffusion orientation, thus any b-value will do. 
    if(i==1){
    tmpmat = tmpvec*tmpvec.t()*0;} 
    else{
    tmpmat = tmpvec*tmpvec.t()*3000;} 
//generates a matrix of the form [Ux^2 UxUy UxUz; UxUy Uy^2 UyUz; UxUz UyUz Uz^2]
    A(i,1) = tmpmat(1,1);  //Ux^2
    A(i,2) = 2*tmpmat(1,2);  //2*UxUy
    A(i,3) = 2*tmpmat(1,3);  //2*UxUz
    A(i,4) = tmpmat(2,2);  //Uy^2
    A(i,5) = 2*tmpmat(2,3);  //UyUz
    A(i,6) = tmpmat(3,3);  //Uz^2
    A(i,7) = 1; 
  
  }
  return A;
}
inline SymmetricMatrix vec2tens(ColumnVector& Vec){

    SymmetricMatrix tens(3);
  tens(1,1)=Vec(1); // Dxx
  tens(2,1)=Vec(2); // Dxy
  tens(3,1)=Vec(3); // Dxz
  tens(2,2)=Vec(4); // Dyy
  tens(3,2)=Vec(5); // Dyz
  tens(3,3)=Vec(6); // Dzz 

  return tens;
}


class Diff_pvm_dwssfp_Model : public ForwardModel  
  {

    const Volume& T1map;
    const Volume& T2map;
    const Volume& B1map;
    //    const Volume& M0map;

  public:
   
    Diff_pvm_dwssfp_Model(const Matrix& pbvecs,const Matrix& pdiffGradDurs, const Matrix& pdiffGradAmps, const Matrix& pflipAngles, const Matrix& pTRs, const Volume& pT1map,const Volume& pT2map,const Volume& pB1map,int pdebuglevel)
      : ForwardModel(pdebuglevel), r(pbvecs) , diffGradDur(pdiffGradDurs), diffGradAmp(pdiffGradAmps), flipAngle(pflipAngles),TR(pTRs), T1map(pT1map),T2map(pT2map),B1map(pB1map),alpha(pdiffGradDurs.Ncols()), beta(pdiffGradDurs.Ncols()), debuglevel(pdebuglevel) 
	
    {
      Amat=form_Amat(r); // form A Matrix needed to calculate tensor
      cart2sph(r,alpha,beta); //transform diffusion encoding directions into spherical coordinates
}
    
    ~Diff_pvm_dwssfp_Model(){}
  
    virtual void setparams();
    ReturnMatrix nonlinearfunc(const ColumnVector& paramvalues, const int& vox) const; 
    void initialise(const ColumnVector& S, const int& vox);

    
  protected:
    
    const Matrix& r;
    const Matrix& diffGradDur;
    const Matrix& diffGradAmp;
    const Matrix& flipAngle;
    const Matrix& TR;
    ColumnVector alpha;
    ColumnVector beta;
    Matrix Amat;
    int debuglevel;
};  

void Diff_pvm_dwssfp_Model::setparams()
  {
    Tracer_Plus tr("Diff_pvm_dwssfp_Model::setdata");
    if(debuglevel>2){
   cout << "Diff_pvm_dwssfp_Model::setparams"<<endl;
    }
    clear_params();
  
    SinPrior thtmp(1,-1000*M_PI,1000*M_PI);
    add_param("th",0.2,0.02,thtmp,true,true); //Will unwrap th param before saving
    //SinPrior phtmp(1,-1000*M_PI,1000*M_PI);
    UnifPrior phtmp(-1000*M_PI,1000*M_PI);
    add_param("ph",0.2, 0.02,phtmp,true,true); //Will unwrap th param before saving
    UnifPrior ftmp(0,1);
    add_param("f",0.5,0.02,ftmp,true,true);
    GammaPrior dtmp(4,1.0/0.0003); //test this out,
    add_param("d",0.005,0.00005,dtmp,true,true);
    UnifPrior S0tmp(0,100000);
    add_param("S0",10000,100,S0tmp,true,true);//false);

    //We have measured values to initialize T1 and T2 but allowing these values to vary a little bit improves the estimates on other variables so I've used a tight Gaussian prior
GaussPrior T1tmp(0.833,0.08,0.67,1.0);
add_param("T1",0.833,0.08,T1tmp,true,true);

 GaussPrior T2tmp(0.065,0.0065,0.052,0.078);
 add_param("T2",0.065,0.0065,T2tmp,true,true);

    
  }

ReturnMatrix Diff_pvm_dwssfp_Model::nonlinearfunc(const ColumnVector& paramvalues, const int& vox) const
  {
    Tracer_Plus trace("Diff_pvm_dwssfp_Model::nonlinearfunc");    
    if(debuglevel>2){
      cout << "Diff_pvm_dwssfp_Model::nonlinearfunc"<<endl;
      cout<<paramvalues<<endl;
          }

float th=paramvalues(1);
    
float ph=paramvalues(2);

float f=paramvalues(3);

float D=paramvalues(4);

float S0=paramvalues(5);

float T1=paramvalues(6);

float T2=paramvalues(7);

 
   double E1, E2, b1, b2, A1_f, A1_r, A2_f, A2_r, s_f, r_bux_f, K_top_f, K_bottom_f, K_f, F1_f, Mminus_top_f, Mminus_bottom_f, Mminus_f;
    double s_r, r_bux_r, K_top_r, K_bottom_r, K_r, F1_r, Mminus_top_r, Mminus_bottom_r, Mminus_r;
    float gyro=2*M_PI*4258; //gyromagnetic ration in Hz/G
    float flip_mod;
    
    ColumnVector ret(r.Ncols());
    float angtmp;
    for (int i = 1; i <= ret.Nrows(); i++){
      //JM: - Recall alpha/beta represent theta(-pi/2: pi/2)/phi(0:2*pi) of the diffusion ENCODING direction that has been measured
      // th, ph are theta(-pi/2:pi/2)/phi(0:2*pi) of the principal axis of the diffusion tensor which we are trying to estimate
 
      //angtmp = r^T R A R^T r, where r=diffusion encoding direction (i.e. alpha/beta), r^T is transposed vector r
      //recall that r is now in spherical coords, thus; rx = sin(alpha)*cos(beta), ry=sin(alpha)*sin(beta), rz=cos(alpha)
      //A is the anisotropic matrix [1 0 0; 0 0 0; 0 0 0]
      //R is  the rotation matrix which rotates A to theta, phi, namely R=Rz_minus_phi * Ry_minus_th

     //original
     angtmp=cos(ph-beta(i))*sin(alpha(i))*sin(th) + cos(alpha(i))*cos(th);
     angtmp=angtmp*angtmp;

     //Use measured B1map to modify prescribed flip angle as required
     if (B1map(vox)!=0)
       {flip_mod=flipAngle(1,i)*B1map(vox);}
     else
       {flip_mod=flipAngle(1,i);}

     //Here is Buxton's beast of an equation for the DW-SSFP signal
     //Be careful it's very easy to make mistakes!

      E1=exp(-TR(1,i)/T1);
      E2=exp(-TR(1,i)/T2);
      b1=( pow(gyro*diffGradAmp(1,i)*diffGradDur(1,i),2.0) )*TR(1,i)/100; //a.k.a. Buxton's b-value, /100 since diffGradAmp is in Gauss per cm and diffusivity is in mm^2/s;
      b2=(pow(gyro*diffGradAmp(1,i)*diffGradDur(1,i),2.0))*diffGradDur(1,i)/100; // a.k.a Buxton's beta
      A1_f=exp(-b1*D); //A1 for isotropic component
      A1_r=exp(-b1*D*angtmp); //A1 for restricted component
      A2_f=exp(-b2*D); //A2 for isotropic component
      A2_r=exp(-b2*D*angtmp); //A2 for restricted component

      //diffusion-weighted signal for isotropic compartment   
      s_f=E2*A1_f*pow(A2_f,-1.33333)*(1-E1*cos(flip_mod))+E2*pow(A2_f,-0.333333)*(cos(flip_mod)-1);
      r_bux_f=1 - E1*cos(flip_mod)+pow(E2,2.0)*A1_f*pow(A2_f,0.333333)*(cos(flip_mod)-E1);
      
K_top_f= 1-E1*A1_f*cos(flip_mod)-pow(E2,2.0)*pow(A1_f,2.0)*pow(A2_f,-0.666667)* (E1*A1_f-cos(flip_mod) );
      
K_bottom_f=(E2*A1_f*pow(A2_f,-1.333333))*(1+cos(flip_mod))*(1-E1*A1_f);      
      K_f=K_top_f/K_bottom_f;
      F1_f=K_f - pow(pow(K_f,2.0) -pow(A2_f,2.0),0.5);
      Mminus_top_f=-(1-E1)*E2*pow(A2_f,-0.666667)*(F1_f-E2*A1_f*pow(A2_f,0.666667))*sin(flip_mod);
      Mminus_bottom_f=r_bux_f-F1_f*s_f;    
      Mminus_f=fabs(Mminus_top_f/Mminus_bottom_f);


      //diffusion-weighted signal for restricted compartment
      s_r=E2*A1_r*pow(A2_r,-1.333333)*(1-E1*cos(flip_mod))+E2*pow(A2_r,-0.333333)*(cos(flip_mod)-1);
      r_bux_r=1 - E1*cos(flip_mod)+pow(E2,2.0)*A1_r*pow(A2_r,0.333333)*(cos(flip_mod)-E1);
      K_top_r=1-E1*A1_r*cos(flip_mod)-pow(E2,2.0)*pow(A1_r,2.0)*pow(A2_r,-0.666667)*(E1*A1_r-cos(flip_mod));
      K_bottom_r=(E2*A1_r*pow(A2_r,-1.333333))*(1+cos(flip_mod))*(1-E1*A1_r);      
      K_r=K_top_r/K_bottom_r;
      F1_r=K_r - pow(pow(K_r,2.0) -pow(A2_r,2.0),0.5);

      Mminus_top_r=-(1-E1)*E2*pow(A2_r,-0.666667)*(F1_r-E2*A1_r*pow(A2_r,0.666667))*sin(flip_mod);
      Mminus_bottom_r=r_bux_r-F1_r*s_r;      
      Mminus_r=fabs(Mminus_top_r/Mminus_bottom_r);
  
      
ret(i)=S0*(f*Mminus_r+(1-f)*Mminus_f);     

    }


    if(debuglevel>2){
      cout<<ret<<endl;
      cout <<"done"<<endl;
          }
    ret.Release();
    return ret; 
}



void Diff_pvm_dwssfp_Model::initialise(const ColumnVector& S, const int& vox){

  Tracer_Plus trace("Diff_pvm_dwssfp_Model::initialise");    
  if(debuglevel>2){
    cout << "Diff_pvm_dwssfp_Model::initialise"<<endl;  
    }

  ColumnVector logS(S.Nrows()),tmp(S.Nrows()),Dvec(7),dir(3);
  
  SymmetricMatrix tens;   //Basser's Diffusion Tensor;
  DiagonalMatrix Dd;   //eigenvalues
  Matrix Vd;   //eigenvectors
  float mDd;
  float th,ph,f,D,S0,T1,T2 ;
    
  //Standard tensor calc to initialize th and ph

  for ( int i = 1; i <= S.Nrows(); i++)
    {
      if(S(i)>0){
	logS(i)=log(S(i));
      }
      else{
	logS(i)=0;
      }
    }

   Dvec = -pinv(Amat)*logS;


     if(  Dvec(7) >  -maxlogfloat ){
   S0=exp(-Dvec(7)); 
   }
   else{
    S0=S.MaximumAbsoluteValue();
}
     
  for ( int i = 1; i <= S.Nrows(); i++)
    {
      if(S0<S.Sum()/S.Nrows()){ S0=S.MaximumAbsoluteValue();  }
   
      logS(i)=(S(i)/S0)>0.01 ? log(S(i)):log(0.01*S0);
    }
 
  Dvec = -pinv(Amat)*logS;

     S0=exp(-Dvec(7)); 
   
 if(S0<S.Sum()/S.Nrows()){ S0=S.Sum()/S.Nrows();  }
 
tens = vec2tens(Dvec);
  EigenValues(tens,Dd,Vd);
  mDd = Dd.Sum()/Dd.Nrows();
  int maxind = Dd(1) > Dd(2) ? 1:2;   //finding maximum eigenvalue
  maxind = Dd(maxind) > Dd(3) ? maxind:3;

  dir << Vd(1,maxind) << Vd(2,maxind) << Vd(3,maxind);
 
  cart2sph(dir,th,ph);
 
   th= mod(th,M_PI);
   ph= mod(ph,2*M_PI);
  //  D = Dd(maxind); //since DW-SSFP does not have a b-value this value will not be meaningful
//for now I have hard-coded the starting value for D to something that is reasonable for fixed tissues
  D=0.0008;///mm2/s
  
  //Likewise FA will also not be meaningful without a b-value
  // float numer=(1.5*(Dd(1)-mDd)*(Dd(1)-mDd)+(Dd(2)-mDd)*(Dd(2)-mDd)+(Dd(3)-mDd)*(Dd(3)-mDd)); 
  //float denom=(Dd(1)*Dd(1)+Dd(2)*Dd(2)+Dd(3)*Dd(3));
  //if(denom>0) fsquared=numer/denom;
  //else fsquared=0;
  //if(fsquared>0){f=sqrt(fsquared);}
  //else{f=0;}

  //for now I will hard-code the starting value for f as well
  f=0.5; 
  T1=T1map(vox)/1000; 
  T2=T2map(vox)/1000;  
 //JM - set S0 to value of low diffusion weighted ssfp data ( q=20 cm^-1) data which is the first dataset
   S0=S(1); 
  // S0=M0map(vox);  //could also use M0maps from DESPOT but I get pretty much the same results with or without
   //for sims
   //S0=300;

  if(f>=0.95) f=0.95;
  if(f<=0.001) f=0.001;
   getparam(0).setinitvalue(th);
   getparam(1).setinitvalue(ph);
  getparam(2).setinitvalue(f);
  getparam(3).setinitvalue(D);
  getparam(4).setinitvalue(S0);
  getparam(5).setinitvalue(T1);
  getparam(6).setinitvalue(T2);

  //JM
 cout<<"Vox "<<vox<<":"<<endl;   
 cout<<"th initial = "<<th<<endl;
  cout<<"ph initial = "<<ph<<endl;
  cout<<"f initial = "<<f<<endl;
 cout<<"D initial = "<<D<<endl;
 cout<<"S0 initial = "<<S0<<endl;
  cout<<"T1 initial = "<<T1<<endl;
  cout<<"T2 initial = "<<T2<<endl;
  
}


int main(int argc, char *argv[])
{
  try{  

    // Setup logging:
    Log& logger = LogSingleton::getInstance();
    
    // parse command line - will output arguments to logfile
    Diff_pvm_dwssfp_Options& opts = Diff_pvm_dwssfp_Options::getInstance();
    opts.parse_command_line(argc, argv, logger);

    srand(Diff_pvm_dwssfp_Options::getInstance().seed.value());
    
    if(opts.debuglevel.value()==1)
      Tracer_Plus::setrunningstackon();
    
    if(opts.timingon.value())
      Tracer_Plus::settimingon();
    
    // read data

    VolumeSeries data;
    cout<<"Reading Data"<<endl;    
    data.read(opts.datafile.value());   
    // data.writeAsFloat(LogSingleton::getInstance().appendDir("data"));
//     cout<<"done"<<endl;
//     return 0;
    int ntpts = data.tsize();
    Matrix bvecs = read_ascii_matrix(opts.bvecsfile.value());
    Matrix diffGradDurs = read_ascii_matrix(opts.diffGradDurfile.value());
    Matrix diffGradAmps = read_ascii_matrix(opts.diffGradAmpfile.value());
    Matrix flipAngles = read_ascii_matrix(opts.flipAnglefile.value());
    flipAngles = flipAngles*M_PI/180;
    Matrix TRs = read_ascii_matrix(opts.TRfile.value());
    
 //normalize vectors if they aren't normalized
if(bvecs.Nrows()>3) bvecs=bvecs.t();
    for(int i=1;i<=bvecs.Ncols();i++){
      float tmpsum=sqrt(bvecs(1,i)*bvecs(1,i)+bvecs(2,i)*bvecs(2,i)+bvecs(3,i)*bvecs(3,i));
      if(tmpsum!=0){
	bvecs(1,i)=bvecs(1,i)/tmpsum;
	bvecs(2,i)=bvecs(2,i)/tmpsum;
	bvecs(3,i)=bvecs(3,i)/tmpsum;
      }  
    }

    // mask:
    Volume mask;
    mask.read(opts.maskfile.value());
    mask.threshold(1e-16);

    //JM - start
    Volume T1map;
    Volume T2map;
    Volume B1map;
    //    Volume M0map;
    T1map.read(opts.T1mapfile.value());
    T1map.setPreThresholdPositions(mask.getPreThresholdPositions());
    T1map.threshold();
    T2map.read(opts.T2mapfile.value());
    T2map.setPreThresholdPositions(mask.getPreThresholdPositions());
    T2map.threshold();
    B1map.read(opts.B1mapfile.value());
    B1map.setPreThresholdPositions(mask.getPreThresholdPositions());
    B1map.threshold();
    //    M0map.read(opts.M0mapfile.value());
    //M0map.setPreThresholdPositions(mask.getPreThresholdPositions());
    //M0map.threshold();

    //JM -end

    
    // threshold using mask:
    data.setPreThresholdPositions(mask.getPreThresholdPositions());
    data.thresholdSeries();

      cout << "ntpts=" << ntpts << endl;
    cout << "nvoxels=" << mask.getVolumeSize() << endl;
  
    //Note changes to the model class in bint:
    //Namely:
    //1.  The "initialise" function will now requires the current voxel number, such that the T1, T2 maps can be used to initialise the estimate of T1 and T2
    //2. The "nonlinearfunc" functions (i.e. the cost function) also requires the current voxel number in order to be able to use the B1 map to 

    Diff_pvm_dwssfp_Model model(bvecs,diffGradDurs,diffGradAmps,flipAngles, TRs, T1map, T2map, B1map,Diff_pvm_dwssfp_Options::getInstance().debuglevel.value());


        LSMCMCManager lsmcmc(Diff_pvm_dwssfp_Options::getInstance(),model,data,mask);
	
	//LSLaplaceManager has been eliminated entirely both here and in bint since the above changes made to model.h created too many conflicts and the LSLSLaplaceManager is not required here
//      LSLaplaceManager lslaplace(Diff_pvm_dwssfp_Options::getInstance(),model,data,mask);
	   
    
//  if(Diff_pvm_dwssfp_Options::getInstance().inference.value()=="mcmc")
//    {
	lsmcmc.setup();
	lsmcmc.run();

	element_mod_n(lsmcmc.getsamples(0),M_PI);
	element_mod_n(lsmcmc.getsamples(1),2*M_PI);
	
	lsmcmc.save();
	
//    }
//  else
//    {
//lslaplace.setup();
//lslaplace.run();
//lslaplace.save();
//    }
    
    if(opts.timingon.value())
      Tracer_Plus::dump_times(logger.getDir());
        cout << endl << "Log directory was: " << logger.getDir() << endl;
 }
  catch(Exception& e) 
    {
      cerr << endl << e.what() << endl;
    }
  catch(X_OptionError& e) 
    {
      cerr << endl << e.what() << endl;
    }

  return 0;
}
