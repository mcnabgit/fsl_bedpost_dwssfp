/*  model.cc

Mark Woolrich, FMRIB Image Analysis Group

Copyright (C) 2002 University of Oxford  */

/*  CCOPYRIGHT  */

#include "model.h"
#include "utils/tracer_plus.h"
#include "miscmaths/miscprob.h"

using namespace Utilities;
using namespace MISCMATHS;

namespace Bint {
 
}
